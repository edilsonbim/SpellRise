﻿#pragma once

#include "CoreMinimal.h"
#include "Abilities/GameplayAbility.h"
#include "GameplayTagContainer.h"
#include "SpellRiseGameplayAbility.generated.h"

class UAbilityTask_WaitInputRelease;

UENUM(BlueprintType)
enum class ESpellRiseCommitPolicy : uint8
{
	CommitOnStart = 0 UMETA(DisplayName="Commit On Start"),
	CommitOnFire  = 1 UMETA(DisplayName="Commit On Fire"),
};

UENUM(BlueprintType)
enum class ESpellRiseAbilityExecutionMode : uint8
{
	/** Compatibilidade com assets antigos:
	 *  - bChannelAbility = true  -> Channel
	 *  - bUseCasting    = true   -> CastRelease
	 *  - caso contrário         -> Instant
	 */
	Legacy      = 0 UMETA(DisplayName="Legacy"),
	Instant     = 1 UMETA(DisplayName="Instant"),
	CastRelease = 2 UMETA(DisplayName="Cast Release"),
	Channel     = 3 UMETA(DisplayName="Channel"),
	MontageFlow = 4 UMETA(DisplayName="Montage Flow"),
};

UCLASS(Blueprintable)
class SPELLRISE_API USpellRiseGameplayAbility : public UGameplayAbility
{
	GENERATED_BODY()

public:
	USpellRiseGameplayAbility();

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="UI")
	bool ShouldShowInAbilityBar = false;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Activation")
	bool AutoActivateWhenGranted = false;

	/** Tag de input desta ability.
	 *  Regra ideal:
	 *  - conceder a ability com este mesmo tag em Spec.GetDynamicSpecSourceTags()
	 *  - o ASC procura por esse tag ao receber input
	 */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Input", meta=(Categories="InputTag"))
	FGameplayTag AbilityInputTag;

	UFUNCTION(BlueprintCallable, Category="Ability")
	void SetAbilityLevel(int32 NewLevel);

	/* ---------------- EXECUTION ---------------- */

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category="Activation")
	ESpellRiseAbilityExecutionMode ExecutionMode = ESpellRiseAbilityExecutionMode::Legacy;

	/* ---------------- CASTING ---------------- */

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category="Casting")
	bool bUseCasting = false;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category="Casting", meta=(EditCondition="bUseCasting", ClampMin="0.0"))
	float CastTime = 1.0f;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category="Casting", meta=(EditCondition="bUseCasting"))
	bool bCancelIfReleasedEarly = false;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category="Casting", meta=(EditCondition="bUseCasting"))
	ESpellRiseCommitPolicy CommitPolicy = ESpellRiseCommitPolicy::CommitOnFire;

	UPROPERTY(BlueprintReadOnly, Category="Casting|State")
	bool bCastCompleted = false;

	UPROPERTY(BlueprintReadOnly, Category="Casting|State")
	bool bInputReleased = false;

	UPROPERTY(BlueprintReadOnly, Category="Casting|State")
	float TimeHeld = 0.f;

	UPROPERTY(BlueprintReadOnly, Category="Input|State")
	bool bInputPressed = false;

	UFUNCTION(BlueprintCallable, Category="Casting")
	void StartCastingFlow();

	UFUNCTION(BlueprintCallable, Category="Casting")
	void FireNow();

	UFUNCTION(BlueprintCallable, Category="Casting")
	void ActivateSpellFlow();

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category="Activation")
	bool bActivateOnSelection = false;

	/** Mantido por compatibilidade com assets antigos. */
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category="Activation")
	bool bChannelAbility = false;

	virtual void InputPressed(
		const FGameplayAbilitySpecHandle Handle,
		const FGameplayAbilityActorInfo* ActorInfo,
		const FGameplayAbilityActivationInfo ActivationInfo
	) override;

	virtual void InputReleased(
		const FGameplayAbilitySpecHandle Handle,
		const FGameplayAbilityActorInfo* ActorInfo,
		const FGameplayAbilityActivationInfo ActivationInfo
	) override;

protected:
	virtual void ActivateAbility(
		const FGameplayAbilitySpecHandle Handle,
		const FGameplayAbilityActorInfo* ActorInfo,
		const FGameplayAbilityActivationInfo ActivationInfo,
		const FGameplayEventData* TriggerEventData) override;

	UFUNCTION(BlueprintNativeEvent, Category="Casting|BP")
	void BP_OnCastStart();
	virtual void BP_OnCastStart_Implementation();

	UFUNCTION(BlueprintNativeEvent, Category="Casting|BP")
	void BP_OnCastCompleted();
	virtual void BP_OnCastCompleted_Implementation();

	UFUNCTION(BlueprintNativeEvent, Category="Casting|BP")
	void BP_OnCastCancelled();
	virtual void BP_OnCastCancelled_Implementation();

	/** Usado por Instant e CastRelease quando efetivamente "solta" a spell. */
	UFUNCTION(BlueprintNativeEvent, Category="Casting|BP")
	void BP_OnCastFired(float ChargeAlpha);
	virtual void BP_OnCastFired_Implementation(float ChargeAlpha);

	/** Chamado no começo do modo Channel. */
	UFUNCTION(BlueprintNativeEvent, Category="Activation|BP")
	void BP_OnChannelStart();
	virtual void BP_OnChannelStart_Implementation();

	/** Chamado no começo do modo MontageFlow. */
	UFUNCTION(BlueprintNativeEvent, Category="Activation|BP")
	void BP_OnMontageFlowStart();
	virtual void BP_OnMontageFlowStart_Implementation();

	UFUNCTION(BlueprintNativeEvent, Category="Casting|BP")
	bool BP_CanFire() const;
	virtual bool BP_CanFire_Implementation() const { return true; }

	virtual void EndAbility(
		const FGameplayAbilitySpecHandle Handle,
		const FGameplayAbilityActorInfo* ActorInfo,
		const FGameplayAbilityActivationInfo ActivationInfo,
		bool bReplicateEndAbility,
		bool bWasCancelled) override;

private:
	bool bHasFired = false;
	bool bActivationFlowStarted = false;

	FTimerHandle CastTimerHandle;

	UPROPERTY(Transient)
	TObjectPtr<UAbilityTask_WaitInputRelease> WaitReleaseTask = nullptr;

	UWorld* GetWorldSafe() const;
	void ResetRuntimeState();
	void ClearCastTimer();
	void ClearReleaseTask();

	UFUNCTION()
	void OnInputReleased(float HeldTime);

	void OnCastComplete();
	void FireInternal();
	float GetChargeAlpha() const;
	bool IsCurrentSpecInputPressed() const;

	ESpellRiseAbilityExecutionMode GetResolvedExecutionMode() const;
	bool ShouldAutoEndAfterFire() const;
};