﻿#pragma once

#include "CoreMinimal.h"
#include "SpellRise/GameplayAbilitySystem/Abilities/SpellRiseGameplayAbility.h"
#include "GA_SR_ProjectileBase.generated.h"

class UAnimMontage;
class UGameplayEffect;
class UProjectileMovementComponent;
class AActor;
class APawn;

UCLASS(Blueprintable)
class SPELLRISE_API UGA_SR_ProjectileBase : public USpellRiseGameplayAbility
{
	GENERATED_BODY()

public:
	UGA_SR_ProjectileBase();

protected:
	/* ---------------- VISUAL / ANIM ---------------- */

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category="Projectile|Animation")
	TObjectPtr<UAnimMontage> CastMontage = nullptr;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category="Projectile|Animation")
	TObjectPtr<UAnimMontage> FireMontage = nullptr;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category="Projectile|Animation", meta=(ClampMin="0.01"))
	float CastMontagePlayRate = 1.0f;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category="Projectile|Animation", meta=(ClampMin="0.01"))
	float FireMontagePlayRate = 1.0f;

	/* ---------------- PROJECTILE ---------------- */

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category="Projectile")
	TSubclassOf<AActor> ProjectileClass;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category="Projectile", meta=(ClampMin="0.0"))
	float ProjectileSpeed = 2500.0f;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category="Projectile")
	FName ProjectileSpawnSocketName = TEXT("Muzzle");

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category="Projectile", meta=(ClampMin="100.0"))
	float TargetTraceRange = 5000.0f;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category="Projectile")
	TEnumAsByte<ECollisionChannel> TargetTraceChannel = ECC_Visibility;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category="Projectile")
	bool bTraceComplex = false;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category="Projectile")
	bool bUseControllerViewForTargeting = true;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category="Projectile")
	ESpawnActorCollisionHandlingMethod SpawnCollisionHandling =
		ESpawnActorCollisionHandlingMethod::AdjustIfPossibleButAlwaysSpawn;

	/* ---------------- DAMAGE ---------------- */

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category="Projectile|Damage")
	TSubclassOf<UGameplayEffect> DamageEffectClass;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category="Projectile|Damage")
	FGameplayTag DamageMagnitudeSetByCallerTag;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category="Projectile|Damage")
	FGameplayTagContainer DamageTypeTags;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category="Projectile|Damage", meta=(ClampMin="0.0"))
	float DamageMagnitude = 50.0f;

protected:
	virtual void BP_OnCastStart_Implementation() override;
	virtual void BP_OnCastCompleted_Implementation() override;
	virtual void BP_OnCastCancelled_Implementation() override;
	virtual void BP_OnCastFired_Implementation(float ChargeAlpha) override;
	virtual bool BP_CanFire_Implementation() const override;

	UFUNCTION(BlueprintCallable, Category="Projectile")
	bool GetProjectileTargetLocation(FVector& OutTargetLocation) const;

	UFUNCTION(BlueprintCallable, Category="Projectile")
	FVector GetProjectileSpawnLocation() const;

	UFUNCTION(BlueprintCallable, Category="Projectile")
	FRotator GetProjectileSpawnRotation(const FVector& TargetLocation) const;

	UFUNCTION(BlueprintCallable, Category="Projectile")
	FGameplayEffectSpecHandle MakeProjectileDamageSpec() const;

	UFUNCTION(BlueprintNativeEvent, Category="Projectile")
	void OnProjectileSpawned(AActor* SpawnedProjectile, const FGameplayEffectSpecHandle& DamageSpec, const FVector& TargetLocation);
	virtual void OnProjectileSpawned_Implementation(AActor* SpawnedProjectile, const FGameplayEffectSpecHandle& DamageSpec, const FVector& TargetLocation);

	UFUNCTION(BlueprintNativeEvent, Category="Projectile")
	void OnCastCompletedNative();
	virtual void OnCastCompletedNative_Implementation();

private:
	void PlayMontageIfValid(UAnimMontage* MontageToPlay, float PlayRate) const;
	void StopMontageIfValid(UAnimMontage* MontageToStop) const;
	APawn* GetAvatarPawn() const;
};