﻿#include "SpellRise/GameplayAbilitySystem/Abilities/SpellRiseGameplayAbility.h"

#include "AbilitySystemComponent.h"
#include "Abilities/Tasks/AbilityTask_WaitInputRelease.h"
#include "TimerManager.h"
#include "Engine/World.h"

USpellRiseGameplayAbility::USpellRiseGameplayAbility()
{
	InstancingPolicy = EGameplayAbilityInstancingPolicy::InstancedPerActor;

	bCancelIfReleasedEarly = false;
	bReplicateInputDirectly = true;

	ResetRuntimeState();
}

void USpellRiseGameplayAbility::ActivateAbility(
	const FGameplayAbilitySpecHandle Handle,
	const FGameplayAbilityActorInfo* ActorInfo,
	const FGameplayAbilityActivationInfo ActivationInfo,
	const FGameplayEventData* TriggerEventData)
{
	Super::ActivateAbility(Handle, ActorInfo, ActivationInfo, TriggerEventData);

	ResetRuntimeState();

	bInputPressed = IsCurrentSpecInputPressed();

	if (bInputPressed)
	{
		ActivateSpellFlow();
	}
}

void USpellRiseGameplayAbility::SetAbilityLevel(int32 NewLevel)
{
	if (FGameplayAbilitySpec* AbilitySpec = GetCurrentAbilitySpec())
	{
		AbilitySpec->Level = NewLevel;
	}
}

UWorld* USpellRiseGameplayAbility::GetWorldSafe() const
{
	if (UWorld* World = GetWorld())
	{
		return World;
	}

	if (CurrentActorInfo && CurrentActorInfo->AvatarActor.IsValid())
	{
		return CurrentActorInfo->AvatarActor->GetWorld();
	}

	return nullptr;
}

bool USpellRiseGameplayAbility::IsCurrentSpecInputPressed() const
{
	if (const FGameplayAbilitySpec* Spec = GetCurrentAbilitySpec())
	{
		return Spec->InputPressed;
	}

	return false;
}

ESpellRiseAbilityExecutionMode USpellRiseGameplayAbility::GetResolvedExecutionMode() const
{
	if (ExecutionMode != ESpellRiseAbilityExecutionMode::Legacy)
	{
		return ExecutionMode;
	}

	if (bChannelAbility)
	{
		return ESpellRiseAbilityExecutionMode::Channel;
	}

	if (bUseCasting)
	{
		return ESpellRiseAbilityExecutionMode::CastRelease;
	}

	return ESpellRiseAbilityExecutionMode::Instant;
}

bool USpellRiseGameplayAbility::ShouldAutoEndAfterFire() const
{
	const ESpellRiseAbilityExecutionMode ResolvedMode = GetResolvedExecutionMode();
	return ResolvedMode == ESpellRiseAbilityExecutionMode::Instant
		|| ResolvedMode == ESpellRiseAbilityExecutionMode::CastRelease;
}

void USpellRiseGameplayAbility::ResetRuntimeState()
{
	bCastCompleted = false;
	bInputReleased = false;
	TimeHeld = 0.f;
	bHasFired = false;
	bInputPressed = false;
	bActivationFlowStarted = false;
}

void USpellRiseGameplayAbility::ClearCastTimer()
{
	if (UWorld* World = GetWorldSafe())
	{
		World->GetTimerManager().ClearTimer(CastTimerHandle);
	}
}

void USpellRiseGameplayAbility::ClearReleaseTask()
{
	if (WaitReleaseTask)
	{
		WaitReleaseTask->EndTask();
		WaitReleaseTask = nullptr;
	}
}

void USpellRiseGameplayAbility::StartCastingFlow()
{
	if (!IsActive() || bHasFired)
	{
		return;
	}

	if (!bInputPressed)
	{
		return;
	}

	bCastCompleted = false;
	bInputReleased = false;
	TimeHeld = 0.f;
	bHasFired = false;

	BP_OnCastStart();

	if (CommitPolicy == ESpellRiseCommitPolicy::CommitOnStart)
	{
		if (!CommitAbility(CurrentSpecHandle, CurrentActorInfo, CurrentActivationInfo))
		{
			EndAbility(CurrentSpecHandle, CurrentActorInfo, CurrentActivationInfo, true, true);
			return;
		}
	}

	ClearReleaseTask();
	WaitReleaseTask = UAbilityTask_WaitInputRelease::WaitInputRelease(this, false);

	if (WaitReleaseTask)
	{
		WaitReleaseTask->OnRelease.AddDynamic(this, &USpellRiseGameplayAbility::OnInputReleased);
		WaitReleaseTask->ReadyForActivation();
	}

	ClearCastTimer();

	if (CastTime <= 0.f)
	{
		OnCastComplete();
		return;
	}

	if (UWorld* World = GetWorldSafe())
	{
		World->GetTimerManager().SetTimer(
			CastTimerHandle,
			this,
			&USpellRiseGameplayAbility::OnCastComplete,
			CastTime,
			false
		);
	}
}

void USpellRiseGameplayAbility::ActivateSpellFlow()
{
	if (!IsActive() || bHasFired)
	{
		return;
	}

	if (bActivationFlowStarted)
	{
		return;
	}

	bActivationFlowStarted = true;

	switch (GetResolvedExecutionMode())
	{
	case ESpellRiseAbilityExecutionMode::Instant:
		FireNow();
		break;

	case ESpellRiseAbilityExecutionMode::CastRelease:
		StartCastingFlow();
		break;

	case ESpellRiseAbilityExecutionMode::Channel:
		BP_OnChannelStart();
		break;

	case ESpellRiseAbilityExecutionMode::MontageFlow:
		BP_OnMontageFlowStart();
		break;

	case ESpellRiseAbilityExecutionMode::Legacy:
	default:
		FireNow();
		break;
	}
}

void USpellRiseGameplayAbility::FireNow()
{
	if (!IsActive() || bHasFired)
	{
		return;
	}

	FireInternal();
}

void USpellRiseGameplayAbility::OnInputReleased(float HeldTime)
{
	if (!IsActive() || bHasFired)
	{
		return;
	}

	bInputReleased = true;
	TimeHeld = HeldTime;

	if (bCastCompleted)
	{
		FireInternal();
		return;
	}

	if (bCancelIfReleasedEarly)
	{
		CancelAbility(CurrentSpecHandle, CurrentActorInfo, CurrentActivationInfo, true);
	}
}

void USpellRiseGameplayAbility::OnCastComplete()
{
	if (!IsActive() || bHasFired)
	{
		return;
	}

	bCastCompleted = true;
	BP_OnCastCompleted();

	if (bInputReleased)
	{
		FireInternal();
	}
}

void USpellRiseGameplayAbility::FireInternal()
{
	if (!IsActive() || bHasFired)
	{
		return;
	}

	if (!BP_CanFire())
	{
		CancelAbility(CurrentSpecHandle, CurrentActorInfo, CurrentActivationInfo, true);
		return;
	}

	bHasFired = true;

	ClearCastTimer();
	ClearReleaseTask();

	if (CommitPolicy == ESpellRiseCommitPolicy::CommitOnFire)
	{
		if (!CommitAbility(CurrentSpecHandle, CurrentActorInfo, CurrentActivationInfo))
		{
			EndAbility(CurrentSpecHandle, CurrentActorInfo, CurrentActivationInfo, true, true);
			return;
		}
	}

	BP_OnCastFired(GetChargeAlpha());

	if (ShouldAutoEndAfterFire())
	{
		EndAbility(CurrentSpecHandle, CurrentActorInfo, CurrentActivationInfo, true, false);
	}
}

void USpellRiseGameplayAbility::InputPressed(
	const FGameplayAbilitySpecHandle Handle,
	const FGameplayAbilityActorInfo* ActorInfo,
	const FGameplayAbilityActivationInfo ActivationInfo)
{
	Super::InputPressed(Handle, ActorInfo, ActivationInfo);

	bInputPressed = true;

	if (IsActive())
	{
		ActivateSpellFlow();
	}
}

void USpellRiseGameplayAbility::InputReleased(
	const FGameplayAbilitySpecHandle Handle,
	const FGameplayAbilityActorInfo* ActorInfo,
	const FGameplayAbilityActivationInfo ActivationInfo)
{
	Super::InputReleased(Handle, ActorInfo, ActivationInfo);

	const bool bWasPressed = bInputPressed;
	bInputPressed = false;

	switch (GetResolvedExecutionMode())
	{
	case ESpellRiseAbilityExecutionMode::CastRelease:
		break;

	case ESpellRiseAbilityExecutionMode::Channel:
		if (IsActive() && bWasPressed)
		{
			CancelAbility(Handle, ActorInfo, ActivationInfo, true);
		}
		break;

	case ESpellRiseAbilityExecutionMode::MontageFlow:
		break;

	case ESpellRiseAbilityExecutionMode::Instant:
	case ESpellRiseAbilityExecutionMode::Legacy:
	default:
		break;
	}
}

float USpellRiseGameplayAbility::GetChargeAlpha() const
{
	if (GetResolvedExecutionMode() != ESpellRiseAbilityExecutionMode::CastRelease)
	{
		return 1.f;
	}

	if (CastTime <= 0.f || bCastCompleted)
	{
		return 1.f;
	}

	return FMath::Clamp(TimeHeld / CastTime, 0.f, 1.f);
}

void USpellRiseGameplayAbility::EndAbility(
	const FGameplayAbilitySpecHandle Handle,
	const FGameplayAbilityActorInfo* ActorInfo,
	const FGameplayAbilityActivationInfo ActivationInfo,
	bool bReplicateEndAbility,
	bool bWasCancelled)
{
	ClearReleaseTask();
	ClearCastTimer();

	if (bWasCancelled && GetResolvedExecutionMode() == ESpellRiseAbilityExecutionMode::CastRelease && !bHasFired)
	{
		BP_OnCastCancelled();
	}

	ResetRuntimeState();

	Super::EndAbility(Handle, ActorInfo, ActivationInfo, bReplicateEndAbility, bWasCancelled);
}

void USpellRiseGameplayAbility::BP_OnCastStart_Implementation()
{
}

void USpellRiseGameplayAbility::BP_OnCastCompleted_Implementation()
{
}

void USpellRiseGameplayAbility::BP_OnCastCancelled_Implementation()
{
}

void USpellRiseGameplayAbility::BP_OnCastFired_Implementation(float ChargeAlpha)
{
}

void USpellRiseGameplayAbility::BP_OnChannelStart_Implementation()
{
}

void USpellRiseGameplayAbility::BP_OnMontageFlowStart_Implementation()
{
}