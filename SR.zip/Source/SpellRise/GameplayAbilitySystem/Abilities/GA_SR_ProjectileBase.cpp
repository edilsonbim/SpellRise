﻿#include "GA_SR_ProjectileBase.h"

#include "AbilitySystemComponent.h"
#include "Abilities/GameplayAbilityTargetTypes.h"
#include "Animation/AnimInstance.h"
#include "Animation/AnimMontage.h"
#include "GameFramework/Character.h"
#include "GameFramework/Controller.h"
#include "GameFramework/Pawn.h"
#include "GameFramework/ProjectileMovementComponent.h"
#include "GameplayEffect.h"
#include "Kismet/GameplayStatics.h"
#include "Engine/World.h"

UGA_SR_ProjectileBase::UGA_SR_ProjectileBase()
{
	ExecutionMode = ESpellRiseAbilityExecutionMode::CastRelease;
	bUseCasting = true;
	CastTime = 3.0f;
	CommitPolicy = ESpellRiseCommitPolicy::CommitOnFire;
	bCancelIfReleasedEarly = false;
}

void UGA_SR_ProjectileBase::BP_OnCastStart_Implementation()
{
	PlayMontageIfValid(CastMontage, CastMontagePlayRate);
}

void UGA_SR_ProjectileBase::BP_OnCastCompleted_Implementation()
{
	OnCastCompletedNative();
}

void UGA_SR_ProjectileBase::BP_OnCastCancelled_Implementation()
{
	StopMontageIfValid(CastMontage);
	StopMontageIfValid(FireMontage);
}

void UGA_SR_ProjectileBase::BP_OnCastFired_Implementation(float ChargeAlpha)
{
	StopMontageIfValid(CastMontage);
	PlayMontageIfValid(FireMontage, FireMontagePlayRate);

	if (!HasAuthority(&CurrentActivationInfo))
	{
		return;
	}

	if (!ProjectileClass)
	{
		UE_LOG(LogTemp, Warning, TEXT("[GA_SR_ProjectileBase] ProjectileClass is null on %s"), *GetNameSafe(this));
		return;
	}

	FVector TargetLocation = FVector::ZeroVector;
	if (!GetProjectileTargetLocation(TargetLocation))
	{
		UE_LOG(LogTemp, Warning, TEXT("[GA_SR_ProjectileBase] Failed to resolve target location on %s"), *GetNameSafe(this));
		return;
	}

	const FVector SpawnLocation = GetProjectileSpawnLocation();
	const FRotator SpawnRotation = GetProjectileSpawnRotation(TargetLocation);

	FGameplayEffectSpecHandle DamageSpec = MakeProjectileDamageSpec();

	FActorSpawnParameters SpawnParams;
	SpawnParams.Owner = GetAvatarActorFromActorInfo();
	SpawnParams.Instigator = GetAvatarPawn();
	SpawnParams.SpawnCollisionHandlingOverride = SpawnCollisionHandling;

	UWorld* World = GetWorld();
	if (!World)
	{
		return;
	}

	AActor* SpawnedProjectile = World->SpawnActorDeferred<AActor>(
		ProjectileClass,
		FTransform(SpawnRotation, SpawnLocation),
		SpawnParams.Owner,
		SpawnParams.Instigator,
		SpawnCollisionHandling
	);

	if (!SpawnedProjectile)
	{
		UE_LOG(LogTemp, Warning, TEXT("[GA_SR_ProjectileBase] SpawnActorDeferred failed for %s"), *GetNameSafe(ProjectileClass));
		return;
	}

	if (UProjectileMovementComponent* ProjectileMoveComp = SpawnedProjectile->FindComponentByClass<UProjectileMovementComponent>())
	{
		ProjectileMoveComp->InitialSpeed = ProjectileSpeed;
		ProjectileMoveComp->MaxSpeed = ProjectileSpeed;
	}

	OnProjectileSpawned(SpawnedProjectile, DamageSpec, TargetLocation);

	UGameplayStatics::FinishSpawningActor(SpawnedProjectile, FTransform(SpawnRotation, SpawnLocation));
}

bool UGA_SR_ProjectileBase::BP_CanFire_Implementation() const
{
	return ProjectileClass != nullptr;
}

bool UGA_SR_ProjectileBase::GetProjectileTargetLocation(FVector& OutTargetLocation) const
{
	const AActor* AvatarActor = GetAvatarActorFromActorInfo();
	if (!AvatarActor)
	{
		return false;
	}

	FVector TraceStart = AvatarActor->GetActorLocation();
	FVector TraceDirection = AvatarActor->GetActorForwardVector();

	if (bUseControllerViewForTargeting)
	{
		if (const FGameplayAbilityActorInfo* ActorInfo = CurrentActorInfo)
		{
			if (AController* Controller = ActorInfo->PlayerController.Get())
			{
				FRotator ViewRotation;
				Controller->GetPlayerViewPoint(TraceStart, ViewRotation);
				TraceDirection = ViewRotation.Vector();
			}
			else if (const APawn* AvatarPawn = Cast<APawn>(AvatarActor))
			{
				if (AController* ControllerFromPawn = AvatarPawn->GetController())
				{
					FRotator ViewRotation;
					ControllerFromPawn->GetPlayerViewPoint(TraceStart, ViewRotation);
					TraceDirection = ViewRotation.Vector();
				}
			}
		}
	}

	const FVector TraceEnd = TraceStart + (TraceDirection * TargetTraceRange);

	FCollisionQueryParams QueryParams(SCENE_QUERY_STAT(GA_SR_ProjectileBase_TargetTrace), bTraceComplex);
	QueryParams.AddIgnoredActor(AvatarActor);

	FHitResult HitResult;
	const bool bHit = GetWorld() && GetWorld()->LineTraceSingleByChannel(
		HitResult,
		TraceStart,
		TraceEnd,
		TargetTraceChannel,
		QueryParams
	);

	OutTargetLocation = bHit ? HitResult.ImpactPoint : TraceEnd;
	return true;
}

FVector UGA_SR_ProjectileBase::GetProjectileSpawnLocation() const
{
	if (const ACharacter* Character = Cast<ACharacter>(GetAvatarActorFromActorInfo()))
	{
		if (const USkeletalMeshComponent* MeshComp = Character->GetMesh())
		{
			if (ProjectileSpawnSocketName != NAME_None && MeshComp->DoesSocketExist(ProjectileSpawnSocketName))
			{
				return MeshComp->GetSocketLocation(ProjectileSpawnSocketName);
			}
		}

		return Character->GetActorLocation() + (Character->GetActorForwardVector() * 100.f) + FVector(0.f, 0.f, 50.f);
	}

	if (const AActor* AvatarActor = GetAvatarActorFromActorInfo())
	{
		return AvatarActor->GetActorLocation() + (AvatarActor->GetActorForwardVector() * 100.f);
	}

	return FVector::ZeroVector;
}

FRotator UGA_SR_ProjectileBase::GetProjectileSpawnRotation(const FVector& TargetLocation) const
{
	const FVector SpawnLocation = GetProjectileSpawnLocation();
	return (TargetLocation - SpawnLocation).GetSafeNormal().Rotation();
}

FGameplayEffectSpecHandle UGA_SR_ProjectileBase::MakeProjectileDamageSpec() const
{
	if (!DamageEffectClass)
	{
		return FGameplayEffectSpecHandle();
	}

	FGameplayEffectContextHandle EffectContext = MakeEffectContext(CurrentSpecHandle, CurrentActorInfo);
	EffectContext.AddSourceObject(GetAvatarActorFromActorInfo());

	FGameplayEffectSpecHandle SpecHandle = MakeOutgoingGameplayEffectSpec(DamageEffectClass, GetAbilityLevel());

	if (!SpecHandle.IsValid() || !SpecHandle.Data.IsValid())
	{
		return FGameplayEffectSpecHandle();
	}

	SpecHandle.Data->SetContext(EffectContext);

	if (DamageMagnitudeSetByCallerTag.IsValid())
	{
		SpecHandle.Data->SetSetByCallerMagnitude(DamageMagnitudeSetByCallerTag, DamageMagnitude);
	}

	if (DamageTypeTags.Num() > 0)
	{
		SpecHandle.Data->AppendDynamicAssetTags(DamageTypeTags);
	}

	return SpecHandle;
}

void UGA_SR_ProjectileBase::OnProjectileSpawned_Implementation(
	AActor* SpawnedProjectile,
	const FGameplayEffectSpecHandle& DamageSpec,
	const FVector& TargetLocation)
{
	// Ponto de extensão:
	// - BP filha pode inicializar componente/projectile movement
	// - passar DamageSpec para uma interface própria do projétil
	// - configurar alvo, VFX, trail etc.
}

void UGA_SR_ProjectileBase::OnCastCompletedNative_Implementation()
{
	// Hook opcional para BP filha.
}

void UGA_SR_ProjectileBase::PlayMontageIfValid(UAnimMontage* MontageToPlay, float PlayRate) const
{
	if (!MontageToPlay)
	{
		return;
	}

	if (ACharacter* Character = Cast<ACharacter>(GetAvatarActorFromActorInfo()))
	{
		Character->PlayAnimMontage(MontageToPlay, PlayRate);
	}
}

void UGA_SR_ProjectileBase::StopMontageIfValid(UAnimMontage* MontageToStop) const
{
	if (!MontageToStop)
	{
		return;
	}

	if (ACharacter* Character = Cast<ACharacter>(GetAvatarActorFromActorInfo()))
	{
		if (USkeletalMeshComponent* MeshComp = Character->GetMesh())
		{
			if (UAnimInstance* AnimInstance = MeshComp->GetAnimInstance())
			{
				AnimInstance->Montage_Stop(0.15f, MontageToStop);
			}
		}
	}
}

APawn* UGA_SR_ProjectileBase::GetAvatarPawn() const
{
	return Cast<APawn>(GetAvatarActorFromActorInfo());
}