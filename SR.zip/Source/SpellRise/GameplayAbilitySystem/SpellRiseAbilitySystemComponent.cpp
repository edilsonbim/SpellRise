﻿#include "SpellRiseAbilitySystemComponent.h"

#include "AbilitySystemBlueprintLibrary.h"
#include "GameplayEffect.h"
#include "GameplayTagContainer.h"
#include "GameFramework/Pawn.h"
#include "SpellRise/Characters/SpellRiseCharacterBase.h"
#include "SpellRise/GameplayAbilitySystem/Abilities/SpellRiseGameplayAbility.h"
#include "SpellRise/GameplayAbilitySystem/AttributeSets/CatalystAttributeSet.h"

static FGameplayTag TAG_State_Dead()
{
	return FGameplayTag::RequestGameplayTag(FName("State.Dead"), false);
}

static FGameplayTag TAG_State_Catalyst_Active()
{
	return FGameplayTag::RequestGameplayTag(FName("State.Catalyst.Active"), false);
}

USpellRiseAbilitySystemComponent::USpellRiseAbilitySystemComponent()
{
	PrimaryComponentTick.bCanEverTick = false;

	InputPressedSpecHandles.Reset();
	InputReleasedSpecHandles.Reset();
	InputHeldSpecHandles.Reset();
}

void USpellRiseAbilitySystemComponent::BeginPlay()
{
	Super::BeginPlay();

	// Não confie 100% em BeginPlay para bindar (ActorInfo pode não estar pronto ainda).
	if (IsOwnerActorAuthoritative())
	{
		EnsureCatalystChargeListenerBound_Server();
	}
}

void USpellRiseAbilitySystemComponent::SR_AbilityInputTagPressed(FGameplayTag InputTag)
{
	if (!InputTag.IsValid())
	{
		return;
	}

	TArray<FGameplayAbilitySpecHandle> MatchingHandles;
	GetAbilitySpecsFromInputTag(InputTag, MatchingHandles);

	for (const FGameplayAbilitySpecHandle& Handle : MatchingHandles)
	{
		InputPressedSpecHandles.AddUnique(Handle);
		InputHeldSpecHandles.AddUnique(Handle);
	}
}

void USpellRiseAbilitySystemComponent::SR_AbilityInputTagReleased(FGameplayTag InputTag)
{
	if (!InputTag.IsValid())
	{
		return;
	}

	TArray<FGameplayAbilitySpecHandle> MatchingHandles;
	GetAbilitySpecsFromInputTag(InputTag, MatchingHandles);

	for (const FGameplayAbilitySpecHandle& Handle : MatchingHandles)
	{
		InputReleasedSpecHandles.AddUnique(Handle);
		InputHeldSpecHandles.Remove(Handle);
	}
}

void USpellRiseAbilitySystemComponent::AbilitySpecInputPressed(FGameplayAbilitySpec& Spec)
{
	Super::AbilitySpecInputPressed(Spec);

	InputPressedSpecHandles.AddUnique(Spec.Handle);
	InputHeldSpecHandles.AddUnique(Spec.Handle);
}

void USpellRiseAbilitySystemComponent::AbilitySpecInputReleased(FGameplayAbilitySpec& Spec)
{
	Super::AbilitySpecInputReleased(Spec);

	InputReleasedSpecHandles.AddUnique(Spec.Handle);
	InputHeldSpecHandles.Remove(Spec.Handle);
}

void USpellRiseAbilitySystemComponent::SR_ClearAbilityInput()
{
	InputPressedSpecHandles.Reset();
	InputReleasedSpecHandles.Reset();
	InputHeldSpecHandles.Reset();
}

bool USpellRiseAbilitySystemComponent::AbilitySpecMatchesInputTag(const FGameplayAbilitySpec& Spec, const FGameplayTag& InputTag) const
{
	if (!InputTag.IsValid() || !Spec.Ability)
	{
		return false;
	}

	// Fonte principal: Spec tags dinâmicos, ideal para AbilitySet / equipamentos / armas
	if (Spec.GetDynamicSpecSourceTags().HasTagExact(InputTag))
	{
		return true;
	}

	// Fallback útil enquanto migra assets antigos
	if (const USpellRiseGameplayAbility* SpellRiseAbility = Cast<USpellRiseGameplayAbility>(Spec.Ability))
	{
		return SpellRiseAbility->AbilityInputTag.IsValid() && SpellRiseAbility->AbilityInputTag.MatchesTagExact(InputTag);
	}

	return false;
}

void USpellRiseAbilitySystemComponent::GetAbilitySpecsFromInputTag(
	const FGameplayTag& InputTag,
	TArray<FGameplayAbilitySpecHandle>& OutSpecHandles) const
{
	OutSpecHandles.Reset();

	if (!InputTag.IsValid())
	{
		return;
	}

	for (const FGameplayAbilitySpec& Spec : GetActivatableAbilities())
	{
		if (AbilitySpecMatchesInputTag(Spec, InputTag))
		{
			OutSpecHandles.AddUnique(Spec.Handle);
		}
	}
}

void USpellRiseAbilitySystemComponent::MarkSpecInputPressed(FGameplayAbilitySpec& Spec)
{
	Spec.InputPressed = true;

	if (Spec.IsActive())
	{
		Super::AbilitySpecInputPressed(Spec);
	}
}

void USpellRiseAbilitySystemComponent::MarkSpecInputReleased(FGameplayAbilitySpec& Spec)
{
	Spec.InputPressed = false;

	if (Spec.IsActive())
	{
		Super::AbilitySpecInputReleased(Spec);
	}
}

bool USpellRiseAbilitySystemComponent::SR_TryActivateAbilityByInputTag(FGameplayTag InputTag)
{
	if (!InputTag.IsValid())
	{
		return false;
	}

	for (FGameplayAbilitySpec& Spec : GetActivatableAbilities())
	{
		if (AbilitySpecMatchesInputTag(Spec, InputTag))
		{
			// IMPORTANTE:
			// a ability precisa ver o input como pressionado já no ActivateAbility.
			Spec.InputPressed = true;

			const bool bAllowRemoteActivation = true;
			return TryActivateAbility(Spec.Handle, bAllowRemoteActivation);
		}
	}

	return false;
}

USpellRiseGameplayAbility* USpellRiseAbilitySystemComponent::SR_GetSpellRiseAbilityForInputTag(FGameplayTag InputTag) const
{
	if (!InputTag.IsValid())
	{
		return nullptr;
	}

	for (const FGameplayAbilitySpec& Spec : GetActivatableAbilities())
	{
		if (AbilitySpecMatchesInputTag(Spec, InputTag))
		{
			return Cast<USpellRiseGameplayAbility>(Spec.Ability);
		}
	}

	return nullptr;
}

void USpellRiseAbilitySystemComponent::SR_ProcessAbilityInput(float DeltaTime, bool bGamePaused)
{
	AActor* Avatar = GetAvatarActor();
	APawn* AvatarPawn = Cast<APawn>(Avatar);

	// Só o pawn local processa input
	if (!AvatarPawn || !AvatarPawn->IsLocallyControlled())
	{
		SR_ClearAbilityInput();
		return;
	}

	if (bGamePaused)
	{
		SR_ClearAbilityInput();
		return;
	}

	TArray<FGameplayAbilitySpecHandle> AbilitiesToActivate;
	AbilitiesToActivate.Reserve(InputPressedSpecHandles.Num());

	TSet<FGameplayAbilitySpecHandle> PressedThisFrame;
	PressedThisFrame.Reserve(InputPressedSpecHandles.Num());

	// 1) Pressed
	{
		const TArray<FGameplayAbilitySpecHandle> PressedSnapshot = InputPressedSpecHandles;

		for (const FGameplayAbilitySpecHandle& Handle : PressedSnapshot)
		{
			PressedThisFrame.Add(Handle);

			FGameplayAbilitySpec* Spec = FindAbilitySpecFromHandle(Handle);
			if (!Spec || !Spec->Ability)
			{
				continue;
			}

			// Marca o estado ANTES da ativação.
			// Isso é obrigatório para casts/holds/channels.
			MarkSpecInputPressed(*Spec);

			if (Spec->IsActive())
			{
				if (!IsOwnerActorAuthoritative() && Spec->Ability->bReplicateInputDirectly)
				{
					ServerSetInputPressed(Spec->Handle);
				}
			}
			else
			{
				AbilitiesToActivate.AddUnique(Handle);
			}
		}
	}

	// 2) Held
	{
		const TArray<FGameplayAbilitySpecHandle> HeldSnapshot = InputHeldSpecHandles;

		for (const FGameplayAbilitySpecHandle& Handle : HeldSnapshot)
		{
			// Evita duplicar o pressed no mesmo frame
			if (PressedThisFrame.Contains(Handle))
			{
				continue;
			}

			FGameplayAbilitySpec* Spec = FindAbilitySpecFromHandle(Handle);
			if (!Spec || !Spec->Ability)
			{
				continue;
			}

			Spec->InputPressed = true;

			if (Spec->IsActive())
			{
				Super::AbilitySpecInputPressed(*Spec);
			}
		}
	}

	// 3) Activate
	for (const FGameplayAbilitySpecHandle& Handle : AbilitiesToActivate)
	{
		FGameplayAbilitySpec* Spec = FindAbilitySpecFromHandle(Handle);
		if (!Spec || !Spec->Ability)
		{
			continue;
		}

		// Garantia extra: entrar no ActivateAbility com input já pressionado.
		Spec->InputPressed = true;

		const bool bAllowRemoteActivation = true;
		TryActivateAbility(Handle, bAllowRemoteActivation);
	}

	// 4) Released
	{
		const TArray<FGameplayAbilitySpecHandle> ReleasedSnapshot = InputReleasedSpecHandles;

		for (const FGameplayAbilitySpecHandle& Handle : ReleasedSnapshot)
		{
			FGameplayAbilitySpec* Spec = FindAbilitySpecFromHandle(Handle);
			if (!Spec || !Spec->Ability)
			{
				continue;
			}

			// Limpa sempre, mesmo se a ability ainda não estiver ativa.
			MarkSpecInputReleased(*Spec);

			if (Spec->IsActive())
			{
				if (!IsOwnerActorAuthoritative() && Spec->Ability->bReplicateInputDirectly)
				{
					ServerSetInputReleased(Spec->Handle);
				}
			}
		}
	}

	InputPressedSpecHandles.Reset();
	InputReleasedSpecHandles.Reset();
}

void USpellRiseAbilitySystemComponent::EnsureCatalystChargeListenerBound_Server()
{
	if (!IsOwnerActorAuthoritative())
	{
		return;
	}

	if (bCatalystListenerBound)
	{
		return;
	}

	if (!GetAvatarActor())
	{
		return;
	}

	BindCatalystChargeListener_Server();
	bCatalystListenerBound = true;
}

void USpellRiseAbilitySystemComponent::BindCatalystChargeListener_Server()
{
	GetGameplayAttributeValueChangeDelegate(
		UCatalystAttributeSet::GetCatalystChargeAttribute()
	).AddUObject(this, &USpellRiseAbilitySystemComponent::OnCatalystChargeChanged);
}

void USpellRiseAbilitySystemComponent::OnCatalystChargeChanged(const FOnAttributeChangeData& Data)
{
	if (!IsOwnerActorAuthoritative())
	{
		return;
	}

	const bool bCrossedToReady = (Data.OldValue < 100.f && Data.NewValue >= 100.f);
	if (!bCrossedToReady)
	{
		return;
	}

	TryProcCatalystIfReady();
}

bool USpellRiseAbilitySystemComponent::TryAddCatalystCharge_OnValidHit(AActor* TargetActor)
{
	if (!IsOwnerActorAuthoritative())
	{
		return false;
	}

	EnsureCatalystChargeListenerBound_Server();

	AActor* SourceActor = GetAvatarActor();
	if (!SourceActor || !TargetActor || TargetActor == SourceActor)
	{
		return false;
	}

	if (HasMatchingGameplayTag(TAG_State_Dead()))
	{
		return false;
	}

	if (HasMatchingGameplayTag(TAG_State_Catalyst_Active()))
	{
		return false;
	}

	if (UAbilitySystemComponent* TargetASC = UAbilitySystemBlueprintLibrary::GetAbilitySystemComponent(TargetActor))
	{
		if (TargetASC->HasMatchingGameplayTag(TAG_State_Dead()))
		{
			return false;
		}
	}

	if (!GE_CatalystAddCharge)
	{
		UE_LOG(LogTemp, Error,
			TEXT("[CAT] GE_CatalystAddCharge is NULL on %s (Owner=%s Avatar=%s). Set it on the ASC component defaults in the Character BP."),
			*GetNameSafe(this),
			*GetNameSafe(GetOwnerActor()),
			*GetNameSafe(GetAvatarActor()));
		return false;
	}

	FGameplayEffectContextHandle Ctx = MakeEffectContext();
	Ctx.AddSourceObject(SourceActor);

	FGameplayEffectSpecHandle SpecHandle = MakeOutgoingSpec(GE_CatalystAddCharge, 1.f, Ctx);
	if (!SpecHandle.IsValid() || !SpecHandle.Data.IsValid())
	{
		UE_LOG(LogTemp, Error, TEXT("[CAT] MakeOutgoingSpec failed for GE_CatalystAddCharge on %s"), *GetNameSafe(SourceActor));
		return false;
	}

	ApplyGameplayEffectSpecToSelf(*SpecHandle.Data.Get());
	return true;
}

bool USpellRiseAbilitySystemComponent::TryAddCatalystCharge_OnDamageTaken(AActor* InstigatorActor)
{
	if (!IsOwnerActorAuthoritative())
	{
		return false;
	}

	EnsureCatalystChargeListenerBound_Server();

	AActor* VictimActor = GetAvatarActor();
	if (!VictimActor)
	{
		return false;
	}

	if (HasMatchingGameplayTag(TAG_State_Dead()))
	{
		return false;
	}

	if (HasMatchingGameplayTag(TAG_State_Catalyst_Active()))
	{
		return false;
	}

	if (InstigatorActor && InstigatorActor == VictimActor)
	{
		return false;
	}

	if (!GE_CatalystAddCharge)
	{
		UE_LOG(LogTemp, Error,
			TEXT("[CAT] GE_CatalystAddCharge is NULL on %s (Owner=%s Avatar=%s). Set it on the ASC component defaults in the Character BP."),
			*GetNameSafe(this),
			*GetNameSafe(GetOwnerActor()),
			*GetNameSafe(GetAvatarActor()));
		return false;
	}

	FGameplayEffectContextHandle Ctx = MakeEffectContext();
	Ctx.AddSourceObject(InstigatorActor ? InstigatorActor : VictimActor);

	FGameplayEffectSpecHandle SpecHandle = MakeOutgoingSpec(GE_CatalystAddCharge, 1.f, Ctx);
	if (!SpecHandle.IsValid() || !SpecHandle.Data.IsValid())
	{
		UE_LOG(LogTemp, Error, TEXT("[CAT] MakeOutgoingSpec failed for GE_CatalystAddCharge on victim %s"), *GetNameSafe(VictimActor));
		return false;
	}

	ApplyGameplayEffectSpecToSelf(*SpecHandle.Data.Get());
	return true;
}

void USpellRiseAbilitySystemComponent::TryProcCatalystIfReady()
{
	if (!IsOwnerActorAuthoritative())
	{
		return;
	}

	EnsureCatalystChargeListenerBound_Server();

	if (HasMatchingGameplayTag(TAG_State_Catalyst_Active()))
	{
		return;
	}

	if (!CatalystProcAbilityClass)
	{
		UE_LOG(LogTemp, Warning, TEXT("[CATALYST] CatalystProcAbilityClass not set."));
		return;
	}

	const float CurrentCharge = GetNumericAttribute(UCatalystAttributeSet::GetCatalystChargeAttribute());
	if (CurrentCharge < 100.f)
	{
		return;
	}

	FGameplayAbilitySpec* Spec = FindAbilitySpecFromClass(CatalystProcAbilityClass);
	if (!Spec)
	{
		UE_LOG(LogTemp, Warning, TEXT("[CATALYST] Proc ability not granted on ASC."));
		return;
	}

	const bool bAllowRemoteActivation = true;
	const bool bActivated = TryActivateAbility(Spec->Handle, bAllowRemoteActivation);

	if (bActivated)
	{
		if (ASpellRiseCharacterBase* Character = Cast<ASpellRiseCharacterBase>(GetAvatarActor()))
		{
			int32 Tier = 1;
			if (const UCatalystAttributeSet* CatAS = Character->GetCatalystAttributeSet())
			{
				Tier = FMath::Clamp(FMath::RoundToInt(CatAS->GetCatalystLevel()), 1, 3);
			}
			Character->MultiOnCatalystProc(Tier);
		}
	}
}

void USpellRiseAbilitySystemComponent::OnRep_ActivateAbilities()
{
	Super::OnRep_ActivateAbilities();

	AActor* Avatar = GetAvatarActor();
	ASpellRiseCharacterBase* Character = Cast<ASpellRiseCharacterBase>(Avatar);
	if (!Character)
	{
		return;
	}

	bool bAbilitiesChanged = (LastActivatableAbilities.Num() != ActivatableAbilities.Items.Num());

	if (!bAbilitiesChanged)
	{
		for (int32 i = 0; i < ActivatableAbilities.Items.Num(); i++)
		{
			if (LastActivatableAbilities.IsValidIndex(i) &&
				LastActivatableAbilities[i].Ability != ActivatableAbilities.Items[i].Ability)
			{
				bAbilitiesChanged = true;
				break;
			}
		}
	}

	if (bAbilitiesChanged)
	{
		Character->SendAbilitiesChangedEvent();
		LastActivatableAbilities = ActivatableAbilities.Items;
	}
}